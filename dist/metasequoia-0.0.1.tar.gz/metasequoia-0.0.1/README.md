# Metasequoia

## 安装方法

```bash
pip install metasequoia
```

## 项目结构

- `application`：部署和应用
- `core`：核心逻辑
- `plugins`：内置插件
- `utils`：工具方法
